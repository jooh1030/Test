function click_login() {
	var url = "popup/login";
	var name = "loginPopup";
	var option = "width=500, height=305, left=100, top=50, locaation=no";
	window.open(url, name, option)
}