function click_login() {
	var url = "../popup/login";
	var name = "loginPopup";
	var option = "width=500, height=450, left=100, top=50, locaation=no";
	window.open(url, name, option)
}

function click_register() {	 
	opener.document.location.href="../member/register"
	self.close();
}