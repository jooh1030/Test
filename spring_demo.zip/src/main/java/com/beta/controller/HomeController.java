package com.beta.controller;

import java.io.IOException;
import java.net.URLEncoder;
import java.util.Locale;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		
		logger.info("Project page reload", locale);
		
		return "home";
	}
	
	@RequestMapping(value = "/map", method = RequestMethod.POST)
	public String mapSearch(@RequestParam(value = "place") String place) throws IOException {
		
		place = URLEncoder.encode(place, "UTF-8"); //�� �ϸ� �����̷�Ʈ �� �ѱ� ����
		
		final String redirectUrl = "redirect:https://map.naver.com/v5/search/"+place;
		
		return redirectUrl;
	}
	
	/*@RequestMapping(value = "/popup/login", method = RequestMethod.GET)
	public String loginPopup(Locale locale, Model model) {
		return "loginPopup";
	}*/
	
	@RequestMapping(value = "/popup/login", method = RequestMethod.GET)
	public ModelAndView loginPopup(HttpSession session) {
		
		ModelAndView mav = new ModelAndView();

		String kakaoUrl = KakaoController.getAuthorizationUrl(session);

		/* ������ ���� URL�� View�� ���� */
		mav.setViewName("member/loginPopup");
		// īī�� �α���
		mav.addObject("kakao_url", kakaoUrl);

		return mav;
	}
	
	
	
}
