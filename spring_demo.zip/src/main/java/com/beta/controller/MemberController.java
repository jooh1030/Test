package com.beta.controller;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.beta.service.MemberService;
import com.beta.vo.MemberVO;
import com.fasterxml.jackson.databind.JsonNode;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/member/*")
public class MemberController {

	private static final Logger logger = LoggerFactory.getLogger(MemberController.class);

	@Inject
	MemberService service;
	
	//���̵� �ߺ� üũ
	@ResponseBody
	@RequestMapping(value="/idChk", method = RequestMethod.POST)
	public int idChk(MemberVO vo) throws Exception {
		int result = service.idChk(vo);
		return result;
	}
	
	//ȸ������ get
	@RequestMapping(value = "/register", method = RequestMethod.GET)
	public void getRegister() throws Exception {
		logger.info("get register");
	}
	
	//ȸ������ post
	@RequestMapping(value = "/register", method = RequestMethod.POST)
	public String postRegister(MemberVO vo) throws Exception {
		logger.info("post register");
		int result = service.idChk(vo);
		
		try {
			if(result == 1) { //���̵� ������ ��� �ٽ� ȸ������ ��������
				return "/member/register";
			} else if(result == 0) { //�������� ���� ��� ����
				service.register(vo);
			}
		} catch (Exception e) {
			throw new RuntimeException();
		}
		
		return "redirect:/";
	}

	//�α���
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public String login(MemberVO vo, HttpServletRequest req, RedirectAttributes rttr) throws Exception {
		logger.info("post login");

		HttpSession session = req.getSession();
		MemberVO login = service.login(vo);
		String test = (String) session.getAttribute("kakaoMsg");
		logger.info(test);
		String loginSucess = "redirect:/popup/login";

		if (login == null) {
			session.invalidate();
			session = req.getSession();
			session.setAttribute("member", null);
			rttr.addFlashAttribute("msg", false);
		} else {
			session.setAttribute("member", login);
		}

		return loginSucess;
	}

	//�α׾ƿ�
	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public String logout(HttpSession session) throws Exception {

		session.invalidate();

		return "redirect:/";
	}

	//īī�� �α���
	@RequestMapping(value = "/kakaoLogin", produces = "application/json", method = { RequestMethod.GET,
			RequestMethod.POST })
	public ModelAndView kakaoLogin(@RequestParam("code") String code, HttpServletRequest req,
			HttpServletResponse response, HttpSession session, RedirectAttributes rttr) throws Exception {
		logger.info("kakao login");
		ModelAndView mav = new ModelAndView();

		JsonNode node = KakaoController.getAccessToken(code); //������� node�� ����
		JsonNode accessToken = node.get("access_token"); //access_token=������� ��� ������ ��� ����

		JsonNode userInfo = KakaoController.getKakaoUserInfo(accessToken);

		String kemail = null; //����� ����
		String kname = null;
		String kgender = null;
		String kbirthday = null;
		String kage = null;
		String kimage = null;

		JsonNode properties = userInfo.path("properties"); //īī������ ���� �������� Get properties
		JsonNode kakao_account = userInfo.path("kakao_account");

		kemail = kakao_account.path("email").asText();
		kname = properties.path("nickname").asText();
		kimage = properties.path("profile_image").asText();
		kgender = kakao_account.path("gender").asText();
		kbirthday = kakao_account.path("birthday").asText();
		kage = kakao_account.path("age_range").asText();

		session.setAttribute("userId", kemail);
		session.setAttribute("kname", kname);
		session.setAttribute("kimage", kimage);
		session.setAttribute("userPass", kgender);
		//session.setAttribute("kgender", kgender);
		session.setAttribute("kbirthday", kbirthday);
		session.setAttribute("kage", kage);
		
		logger.info(kemail + "/" + kname + "/" + kimage  + "/" + kgender + "/" + kbirthday + "/" + kage);
		
		mav.setViewName("redirect:/popup/login");
		
		return mav;
	}
	
	//īī�� �α����̾��µ� null�� �Ѿ�� ������ �𸣰��� get�̶� �׷���
	/*@RequestMapping(value = "/kakaoIdOk", method = RequestMethod.GET)
		public String kakaoIdOk(MemberVO vo, HttpServletRequest req, RedirectAttributes rttr) throws Exception {
			logger.info("get kakao login");

			HttpSession session = req.getSession();
			MemberVO kakaoLogin = service.kakaoLogin(vo);
			String loginSucess = "redirect:/popup/login";
			
			if (kakaoLogin == null) { //NULL�� ������ ������ ����
				session.setAttribute("member", null);
				session.setAttribute("kakaoMsg", "?DFDfdf");
				//rttr.addFlashAttribute("kakaoMsg", "?DFDfdf");
			} else {
				session.setAttribute("member", kakaoLogin);
				session.setAttribute("kakaoMsg", "asdfasdf");
			}

			return loginSucess;
		}*/

}
