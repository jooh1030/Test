package com.beta.service;

import java.util.List;

import com.beta.vo.ReplyVO;

public interface ReplyService {
	
	//��� ��ȸ
	public List<ReplyVO> readReply(int bno) throws Exception;

}
