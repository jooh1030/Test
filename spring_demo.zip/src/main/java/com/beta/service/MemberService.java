package com.beta.service;

import com.beta.vo.MemberVO;

public interface MemberService {

    public MemberVO login(MemberVO vo) throws Exception;

}