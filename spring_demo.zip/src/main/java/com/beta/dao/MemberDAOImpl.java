package com.beta.dao;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.beta.vo.MemberVO;

@Repository
public class MemberDAOImpl implements MemberDAO {

    @Inject
    SqlSession sql;
    
    //ȸ������
    @Override
    public void register(MemberVO vo) throws Exception {
    	sql.insert("memberMapper.register", vo);
    }
    
    //���̵� �ߺ� üũ
    @Override
    public int idChk(MemberVO vo) throws Exception {
    	int result = sql.selectOne("memberMapper.idChk", vo);
    	return result;
    }
    
    //�α���
    @Override
    public MemberVO login(MemberVO vo) throws Exception {
        // TODO Auto-generated method stub
        return sql.selectOne("memberMapper.login", vo);
    }
    
    //īī�� �α���
    @Override
    public MemberVO kakaoLogin(MemberVO vo) throws Exception {
        // TODO Auto-generated method stub
        return sql.selectOne("memberMapper.kakaoLogin", vo);
    }
}