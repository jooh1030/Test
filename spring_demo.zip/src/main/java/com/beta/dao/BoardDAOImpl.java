package com.beta.dao;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.beta.vo.BoardVO;

@Repository
public class BoardDAOImpl implements BoardDAO {
	
    @Inject
    private SqlSession sqlSession;

	// �Խù� ��� ��ȸ
	@Override
	public List<BoardVO> list() throws Exception {

		return sqlSession.selectList("boardMapper.list");

	}
	
	// �Խù� ��ȸ
	@Override
	public BoardVO read(int bno) throws Exception {
			
		return sqlSession.selectOne("boardMapper.read", bno);
	}

}
