package com.beta.dao;

import java.util.List;

import com.beta.vo.BoardVO;

public interface BoardDAO {
	
	//�Խù� ��� ��ȸ
	public List<BoardVO> list() throws Exception;
	
	//�Խù� ��ȸ
	public BoardVO read(int bno) throws Exception;

}
