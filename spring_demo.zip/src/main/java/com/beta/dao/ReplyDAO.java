package com.beta.dao;

import java.util.List;

import com.beta.vo.ReplyVO;

public interface ReplyDAO {
	
	//��� ��ȸ
	public List<ReplyVO> readReply(int bno) throws Exception;

}
